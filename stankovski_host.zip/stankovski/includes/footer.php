<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<footer>
    <center>
        <h2>Metal-Inzenering</h2>
        <span>Copyrights © 2021-<?php echo Date("Y") ?></span>
        <p>Development By: <a href="" id="developer" >Dario Stankovski</a> </p>
    </center>
</footer>
